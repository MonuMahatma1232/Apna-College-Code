package Recursion;
// print x^n in 0(logn)
public class Problmes10 {
    
    //
}
