package Recursion;
// Problems09
public class PowerProblems09 {
    public static void main(String[] args) {

    }
}
