package CONDITIONALS_08;

public class Check_StudenPassOrFail {
    public static void main(String[] args) {
        int marks = 33;
        String Status = ((marks<=33)) ? "fail" : "Pass";
        System.out.println(Status);
    }
}
