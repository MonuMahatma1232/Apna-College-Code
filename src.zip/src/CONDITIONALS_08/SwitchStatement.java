package CONDITIONALS_08;

import javax.sound.midi.Soundbank;

public class SwitchStatement {
    public static void main(String[] args) {
        int number = 2;
        switch (number){
            case 1 :
                System.out.println("Samosa");
                break;
            case 2:
                System.out.println("Burger");
                break;
            case 3:
                System.out.println(" mango Shake");
                break;
            default:
                System.out.println("we weak up");
        }
    }
}
