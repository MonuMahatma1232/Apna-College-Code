package CONDITIONALS_08.PracticsSet_08;

public class Question_04{public static void main(String args[]) {
    int a=63,b=36;
    boolean x= (a<b)?true:false;
            int y= (a>b)?a:b;
    }
}
