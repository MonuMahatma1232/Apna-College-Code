package Queues;
import java.util.*;
//Question_05
//First non-repeating number int a stream of characters.
//aabcxb
public class NonRepeatingLatter {

    public static void main(String[] args) {


    }
}
