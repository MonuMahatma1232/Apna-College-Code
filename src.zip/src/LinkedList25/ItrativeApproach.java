package LinkedList25;

public class ItrativeApproach {
    // Find & remove Nth node from the end
    
    public static void main(String[] args) {

    }
}
