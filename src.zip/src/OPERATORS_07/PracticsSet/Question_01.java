package OPERATORS_07.PracticsSet;

public class Question_01 {
    public static void main(String[] args) {
        int x = 2, y = 5;

    int exp1 = (x * y / x);
    float exp2 = (x * (y / x));
    System.out.print(exp1 + " , ");
    System.out.print(exp2);
 }
}
