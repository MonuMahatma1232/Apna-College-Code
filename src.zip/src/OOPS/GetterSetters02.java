package OOPS;

public class GetterSetters02 {
    class  pen{
        String color;
        int tip;

        String getColor(){
            return this.color;
        }

        void  setColor(String newColor){
            color = newColor;

        }
        void setTip(int nTip){
            this.tip = nTip;
        }


    }
}
