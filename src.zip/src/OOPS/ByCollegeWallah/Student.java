package OOPS.ByCollegeWallah;

public  class Student {
    String name;
    int rno;
    double present;
}
//class in differant file but same package
