package OOPS.ByCollegeWallah;

public class StudentClassGeneral {
    // create a new data type
    public  static void change(Student s){

}



    public static void main(String[] args) {

        Student x = new Student();
        x.name = "mahatma";
        x.rno = 78;
        x.present = 98.9;
        System.out.println(x.rno + 5);
        Student s = new Student();
        s.name = "Abhimanyu";
        s.present = 95.5;
        s.rno = 00;

    }
}
