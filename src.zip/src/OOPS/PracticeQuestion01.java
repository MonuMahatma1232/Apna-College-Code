package OOPS;

public class PracticeQuestion01 {
    class Student{
        String name;
        int marks;

    }

    public static void main(String[] args) {
        //s.name = new Student();




    }
}
