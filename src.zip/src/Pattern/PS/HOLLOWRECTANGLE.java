package Pattern.PS;

public class HOLLOWRECTANGLE {
    public static void main(String[] args) {

    }
}
