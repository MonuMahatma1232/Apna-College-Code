package Pattern;

public class Question_01 {
    public static void main(String[] args) {
        System.out.println("****");
        System.out.println("***");
        System.out.println("**");
        System.out.println("*");

        // Variable in java

        int a = 39;
        int b = 283;
        int sum = a + b;
        System.out.println(sum);

        // for find the paremeter of square
        int length = 33;
        int brath = 34;
        int paremeter = 2 * (a + b);
        System.out.println("the Paremeter is:" + paremeter);
    }
}