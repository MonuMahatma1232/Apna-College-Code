package Stacke_26;

public class IsDuplicteParantheses {
    
}
