package PracticsSetBitmanupulation;
 // Question 1 :What is the value of x^x for any valueof x?;

public class Qestion01 {
 public static void main(String args[]){
  System.out.println("The value of x^x = 0.Think about it,xor gives 0 when the bits are the same.If we compare the same number to itself, the bits will always be the same. So, " +
          "the answer of x^x will always be 0");
 }


}
