package FUNCTION;

public class CH_01 {
    public static void printHelloWorlds(){
        System.out.println("hello World");
        System.out.println("hello Mahatma");
        System.out.println("hello mahatma je");
    }

    public static void main(String[] args) {
        printHelloWorlds(); // function call

    }
}
