//package FUNCTION;
//
//public class Ch_06_Coficient {
//    public static int binCoeff(int n, int r) {
//        int fact_n = Factorial(n);
//        int fact_r = factoriall(r);
//        int fact_nmr = factoriall(n - r);
//
//        int binCoeff = fact_n / (fact_r * fact_nmr);
//        return binCoeff;
//    }
//
//    public static void main(String[] args) {
//        System.out.println(binCoeff(5, 2));
//    }
//
//
//        }
//}
