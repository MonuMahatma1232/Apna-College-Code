package VariableDataTypes_06;

public class Question_04 {
    public static void main(String[] args) {
        //Question 4:What will be the type of result in the following Java code?

        byte b  = 4;
        char c = 'a';
        short s = 512;
        int i = 1000;
        float f = 3.14f;
        double d = 99.9954;
     // result = (f * b) + (i % c ) - (d * s);
        //In the mentioned code, the result variable will be of double type because of type conversion

    }
}
