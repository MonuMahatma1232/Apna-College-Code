package VariableDataTypes_06;
import java.util.*;
public class Question_02 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
         int side = sc.nextInt();

         int Area  = side *  side;
        System.out.println("Area of Square is: "+ Area);

    }
}
