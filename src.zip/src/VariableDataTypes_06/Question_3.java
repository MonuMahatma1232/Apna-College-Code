package VariableDataTypes_06;
import java.util.Scanner;

public class Question_3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        float pen = sc.nextFloat();
        float pencil = sc.nextFloat();
        float eraser = sc.nextFloat();

        float total = (pen + pencil + eraser);
        System.out.println("Total cost of things is: " + total);

        //aad with - if 18% tax



    }
}
