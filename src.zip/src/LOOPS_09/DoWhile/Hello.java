package LOOPS_09.DoWhile;

public class Hello {
    public static void main(String[] args) {
        int counter = 1;

        do{
            System.out.println("hello Mahatma");
            counter++;

        }while (counter <= 10);

    }
}
