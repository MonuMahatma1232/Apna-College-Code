package LOOPS_09.WhileLoop;


public class wHILELOPS {
    public static void main(String[] args) {
        int counter = 0;
        while (counter<100){
            System.out.println("namastay te mahatma je");
            counter++;
        }
        System.out.println("printed 100 times");
    }
}
