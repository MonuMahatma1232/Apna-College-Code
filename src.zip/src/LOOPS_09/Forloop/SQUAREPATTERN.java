package LOOPS_09.Forloop;

public class SQUAREPATTERN {
    public static void main(String[] args) {
//        for(int i=1; i<=4; i++){
//            System.out.println("****");
//        }

        // According to whole loops
        int i = 1;
        while (i<=4){
            System.out.println("****");
            i++;
        }

    }
}
