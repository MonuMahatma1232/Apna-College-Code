package LOOPS_09.Forloop;

public class ps_01 {
    public static void main(String[] args) {
       // int i = 1;

        for(int i=1; i<=10; i++){
            System.out.println("Hello Mahatma");
        }
        System.out.println(" i times Hello Mahatma: ");
    }
}
