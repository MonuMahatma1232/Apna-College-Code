package ChallengesOf100Question;

public class CommandLineArgument03 {
    public static void main(String args[]){
        for (String t: args){
            System.out.println(t);
        }
    }
}
