package ChallengesOf100Question;

public class PrintInteger02 {
    public static void main(String args[]){
        int c; // declaring a variable;

        /* Using for loop to repeat instruction executing */

        for(c = 1; c<=1; c++){
            System.out.println(c);
        }

    }
}
