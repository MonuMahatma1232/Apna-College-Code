package ChallengesOf100Question;

public class SimpleJavaProgram01 {
    public static void main(String arg[]){
        System.out.println("Hello World by Mahatma Jee");
    }
}
